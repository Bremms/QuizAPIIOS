//
//  Game.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 18/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//
//Singleton class that stores are gameobjects and handles everything gamewise
import Foundation

class Game{
    
    static let Instance = Game()
    
    var Categories : [QuizCategory]
    var CurrentSelectedCategory : QuizCategory?
    var CurrentQuestionIndex = 0
    var CurrentSelectedQuestions : [QuizQuestion]?
    var CurrentScore : Int
    private init(){
        Categories = [QuizCategory]()
        CurrentScore = 0
    }
    
    func SetQuestionEntries(quizQuestions : [QuizQuestion]){
        CurrentSelectedQuestions = quizQuestions
        CurrentQuestionIndex = 0
    }
    
    func GetNextQuestion() -> QuizQuestion?{
        CurrentQuestionIndex += 1
        let question = GetCurrentQuestion()
      
        return question
    }
    
    func OnQuestionAnswered(answerID : Int){
        var currentQuestion = GetCurrentQuestion()
        let isCorrectAnswer = currentQuestion!.AnswerQuestion(id: answerID)
        
        if(isCorrectAnswer){
            CurrentScore += GetCurrentQuestion()!.GetReward()
        }
    }
    
    func OnQuestionAnswered(answer : String){
        var currentQuestion = GetCurrentQuestion() as! OpenQuestion
        let isCorrectAnswer = currentQuestion.AnswerOpenQuestion(answer: answer)
        
        if(isCorrectAnswer){
            CurrentScore += GetCurrentQuestion()!.GetReward()
        }
    }
    
    func GetCurrentQuestion() -> QuizQuestion? {
        if(CurrentSelectedQuestions == nil){
            return nil
        }
        var count = CurrentSelectedQuestions!.count
        if(CurrentQuestionIndex >= CurrentSelectedQuestions!.count){
            return nil
        }else{
            return CurrentSelectedQuestions![CurrentQuestionIndex]
        }
        
        
    }
    
    func SelectCategory(category cat: QuizCategory){
        CurrentSelectedCategory = cat
    }
    
    func fetchRandomCategories() -> [QuizCategory]{
        do{
            Categories = try DAL.Instance.FetchRandomCategories()
          
            
        }catch {
            print("Error with handling categories. Is debug mode on ? ")
        }
        
        return Categories
    }
    
   
    
}

