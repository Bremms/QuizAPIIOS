//
//  HighScore.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 24/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class HighScore {
    
    var PersonTag : String
    var CatID : Int
    var Score : Int
    var ID : Int
    init(id : Int, personTag : String,score : Int,catID : Int){
        
        PersonTag = personTag
        ID = id
        Score = score
        CatID = catID
    
    }
    
    
}
