//
//  DAL.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class DAL {
 
   
    let CategoryRepo : RepositoryProtocol
    let HighScoreRepo : RepositoryProtocol
    static let Instance = DAL()
    
    private init() {
        //DebugMode fetch dummyrepositorys .. I will implement service later when i'm on windows laptop.. Because backend will by .net WebApi
        
        if Default.GAME_ON_DEBUG.rawValue == "1" {
            CategoryRepo = DummyCategoryRepository()
            HighScoreRepo = DummyHighScoreRepository()
        }else{
            CategoryRepo = CategoryRepository()
            HighScoreRepo = DummyHighScoreRepository()
        }
    }
    
    func FetchRandomCategories() throws -> [QuizCategory] {
        do{
            let categories = try CategoryRepo.FetchRandom(amount: 5) as [QuizCategory]
            
            return categories
            
        }catch GameErrors.NotImplemented {
            throw GameErrors.NotImplemented
        }

    }
    
    func FetchHighscores(categoryID catID : Int) throws ->  [HighScore]{
      
        do{
            var highScores = try HighScoreRepo.Fetch(ByID: catID) as [HighScore]
            
            return highScores
        }catch{
             throw GameErrors.NotImplemented
        }
    }
    
    func StoreScore(score : Int , categoryID catID : Int){
        let gamerTag =  UserDefaults.standard.string(forKey: Default.USERKEY.rawValue)
        let newHighScore = HighScore(id: 0, personTag: gamerTag!, score: score, catID: catID)
        do{
            try   HighScoreRepo.Save(obj: newHighScore)
        }catch{
            
        }
      
    }
    
}
