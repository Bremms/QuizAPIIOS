//
//  QuizCategory.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class QuizCategory {
    var Name : String
    var CategoryAvgDificulty : Int
    var ID : Int
    var Description : String
    init(name : String,avgDificulty : Int,id : Int,description : String){
        Name = name
        ID = id
        CategoryAvgDificulty = avgDificulty
        Description = description
    }
    
    
}
