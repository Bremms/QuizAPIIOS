//
//  QuizQuestion.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class QuizQuestion{
    
    var Question : String
    var PhotoInternalPath : String? //Path to internal file
    var PhotoExternalURL : String? //URL to a website
    var CategoryID : Int
    var ID : Int
    let InitTimer = 30
    var Timer : Int
   
    var PotentialAnswers : [QuizAnswer]
    var GameActivityHandler : GameActivityProtocol? //Protocol to notify controller about critical changes
    
    
    init(categoryID catID : Int, id : Int, question : String, photoInternalPath : String?, photoExternalUrl : String?){
        ID = id
        CategoryID = catID
        Question = question
        PhotoInternalPath = photoInternalPath
        PhotoExternalURL = photoExternalUrl
        PotentialAnswers = [QuizAnswer]()
        Timer = InitTimer //default 30seconds to answer a question
    
 
    }
    
    func SetGameActivityHandler(gameActivityHandler handler : GameActivityProtocol){
        GameActivityHandler = handler
    }
    
    func addAnswer(answer : QuizAnswer){
        PotentialAnswers.append(answer)
        GameActivityHandler != nil ? GameActivityHandler!.OnRepaintScreen() : ()
    }
    
    func TimerElapsed(){
        Timer = Timer - 1
        
        if Timer == 0 {
            GameActivityHandler != nil ? GameActivityHandler!.OnTimerEnded() : ()
        }
        
    }
    
    func AnswerQuestion(id : Int) -> Bool{
        let foundAnswer = SearchAnswerByID(id: id)
        if foundAnswer != nil{
            return foundAnswer!.IsAnswer
        }
        return false
    }
    
    func GetReward() -> Int {
       return Timer //Default implementation of get raward
    }
    
    private func SearchAnswerByID(id : Int) -> QuizAnswer?{
        if let i = PotentialAnswers.index(where : {$0.ID == id}){
            return PotentialAnswers[i]
        }
        return nil
    }
    
    public func GetAmountNonDisabled() -> Int{
        var amt = 0
        
        for answer in PotentialAnswers{
            if(answer.IsDisabled){
                amt += 1
            }
        }
        
        return amt
        
    }
    
}
