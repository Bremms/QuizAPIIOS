//
//  QuizAnswer.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 18/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation
class QuizAnswer {
    var ID : Int
    var QuizQuestionID : Int
    var Description : String
    var IsAnswer = Bool()
     var IsDisabled : Bool
    init(id : Int, quizQuestionID : Int, description : String, isAnwser : Bool){
        ID = id
        IsAnswer = isAnwser
       QuizQuestionID =  quizQuestionID
        Description = description
        IsDisabled  = false
    }
    
}
