//
//  CategoryRepository.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//
//
import Foundation

class CategoryRepository : RepositoryProtocol{
    func Save(obj: Any) throws {
        throw GameErrors.NotImplemented
    }
    
    func Fetch<T>(ByID: Int) throws -> [T] {
        throw GameErrors.NotImplemented
    }
    
    func FetchRandom<QuizCategory>(amount: Int) throws -> [QuizCategory] {
         throw GameErrors.NotImplemented
    }
    
    func Fetch<QuizCategory>() throws -> [QuizCategory] {
        throw GameErrors.NotImplemented
    }
    
    func FirstOrDefault<QuizCategory>(id: Int) throws -> QuizCategory {
        throw GameErrors.NotImplemented
        
    }
    
    
}
