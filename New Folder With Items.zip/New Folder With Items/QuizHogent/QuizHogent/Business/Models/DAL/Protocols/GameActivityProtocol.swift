//
//  GameActivityProtocol.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 22/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation


protocol GameActivityProtocol{
 
    func OnRepaintScreen() //Indiciates that there is change in the status of the gameObject and the controller has to act on it.
    
    func DisableElement(object : Any) //Fires if there is an object that has to be disabled
    
    func OnTimerEnded()
    
    
    
}
