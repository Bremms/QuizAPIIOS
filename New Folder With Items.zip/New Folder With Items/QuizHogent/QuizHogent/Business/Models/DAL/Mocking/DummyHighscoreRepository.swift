//
//  DummyHighscoreRepository.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 24/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class DummyHighScoreRepository : RepositoryProtocol{
   
    func Save(obj: Any) throws {
        let highscore = obj as! HighScore
        HighScores.append(highscore)
        
    }
    
    
   var  HighScores : [HighScore]
    
    init(){
        HighScores = [HighScore]()
        HighScores.append(HighScore(id : 1, personTag: "ADB", score: 90, catID : 5))
         HighScores.append(HighScore(id : 2, personTag: "John", score: 80, catID : 5))
         HighScores.append(HighScore(id : 3, personTag: "XDB", score: 75, catID : 5))
         HighScores.append(HighScore(id : 4, personTag: "ADB", score: 74, catID : 5))
         HighScores.append(HighScore(id : 5, personTag: "ADB", score: 69, catID : 5))
         HighScores.append(HighScore(id : 6, personTag: "ADB", score: 69, catID : 5))
         HighScores.append(HighScore(id : 7, personTag: "ADB", score: 68, catID : 5))
    }
    
    func Fetch<T>() throws -> [T] {
    throw GameErrors.NotImplemented
    }
    
    func Fetch<HighScore>(ByID: Int) throws -> [HighScore] {
        var newArray = [HighScore]()
        
        for score in HighScores{
            if(score.CatID == ByID){
                let score_ = score as! HighScore
                newArray.append(score_)
            }
        }
      return newArray
    
    }
    
    func highscoreSorter(this:HighScore, that:HighScore) -> Bool {
        return this.Score > that.Score
    }
    
    func FetchRandom<T>(amount: Int) throws -> [T] {
        throw GameErrors.NotImplemented
    }
    
    func FirstOrDefault<T>(id: Int) throws -> T! {
        throw GameErrors.NotImplemented
    }
    
    
}
