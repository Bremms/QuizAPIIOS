//
//  DummyCategoryRepository.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation
import GameplayKit

class DummyCategoryRepository : RepositoryProtocol{
    func Save(obj: Any) throws {
        GameErrors.NotImplemented
    }
    
    func Fetch<T>(ByID: Int) throws -> [T] {
        throw GameErrors.NotImplemented
    }
    
    var categories : [QuizCategory]
    
    init(){
        //Made al ID = 5  because we only have questions for 5
        categories = [QuizCategory]()
        categories.append(QuizCategory(name : "Coding", avgDificulty : 1, id : 5, description: "Deze category bevat vragen over algoritmes en code"))
        
        categories.append(QuizCategory(name : "Coding 2", avgDificulty : 3, id : 5,description : "Deze cateogry bevat vragen over algoritmes en designprincipes"))
        
        categories.append(QuizCategory(name : "Geschiedenis", avgDificulty : 2, id : 5,description : "Deze category bevat vragen over de 2 wereldoorlogen"))
        
        categories.append(QuizCategory(name : "Geschiedenis 2", avgDificulty : 4, id : 5,description : "Deze category bevat geschiedenisvragen"))
        
        categories.append(QuizCategory(name : "Football", avgDificulty : 2, id : 5,description:"Deze categorie bevat vragen over het huidige voetbal"))
        
        categories.append(QuizCategory(name : "Football 2", avgDificulty : 4, id : 5, description:"Deze categorie bevat vragen over de history van de voetbal"))
        
        categories.append(QuizCategory(name : "Inventions", avgDificulty : 1, id : 5,description: "algemene vragen over uitvindingen"))
        
         categories.append(QuizCategory(name : "Inventions 2", avgDificulty : 5, id : 5,description: "algemene vragen over uitvindingen"))
    }
    
    func Fetch<QuizCategory>() throws -> [QuizCategory] {
        return categories as! [QuizCategory]
    }
    
    
    func FetchRandom<QuizCategory>(amount: Int) throws -> [QuizCategory] {
        
        //https://www.hackingwithswift.com/read/35/3/generating-random-numbers-with-gameplaykit-gkrandomsource
        
        let shuffledArraySlices = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: categories).prefix(amount)
        
        let shuffledArray : [QuizCategory] = Array(shuffledArraySlices) as! [QuizCategory]
        
        return shuffledArray

        
    }
    
    func FirstOrDefault<QuizCategory>(id: Int) throws -> QuizCategory!{
        if let i = categories.index(where : {$0.ID == id}){
            return categories[i] as! QuizCategory
        }
        return nil
    }
    
    
}
