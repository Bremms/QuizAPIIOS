//
//  ButtonView.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 23/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//
// Strongly based upon https://medium.com/written-code/creating-uiviews-programmatically-in-swift-55f5d14502ae --> but used carthage instead of cocoapop Also complete different flow

import UIKit
import PureLayout

//
class ButtonView : UIView {
    
    var shouldSetupConstraints = true
    var quizAnswers : [QuizAnswer]
    var ButtonViews : [UIButton]
    var AnchorView : UIView?
     var initialConstraints = [NSLayoutConstraint]()
 let screenSize = UIScreen.main.bounds
    
    
    override init(frame: CGRect) {
        quizAnswers = [QuizAnswer]()
          ButtonViews = [UIButton]()
        super.init(frame: frame)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func updateConstraints() {
        if(shouldSetupConstraints) {
            // AutoLayout constraints
            shouldSetupConstraints = false
        }
        
        super.updateConstraints()
    }
    
    func setAnswers(answers : [QuizAnswer]){
        quizAnswers = answers
        
    }
    func setAnchorView(view : UIView){
        AnchorView = view
        let leadingConstraint = self.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant : 0)
        let trailingConstraint = self.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant:0)
        let topContraint = self.topAnchor.constraint(equalTo: view.topAnchor, constant:0)
         let bottom = self.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant:0)
        initialConstraints.append(contentsOf: [leadingConstraint,trailingConstraint,topContraint,bottom])
        
       // self.addSubview(view)
    }
    
    public func AddAnswersToView(){
        self.backgroundColor = UIColor.blue
        ButtonViews = [UIButton]()
        
        for var i in 0..<quizAnswers.count{
            var answer = quizAnswers[i]
            
            let newButton = UIButton()
            newButton.translatesAutoresizingMaskIntoConstraints = false
            
            newButton.setTitle(answer.Description, for: UIControlState.normal)
            newButton.backgroundColor = UIColor.blue
            ButtonViews.append(newButton)
            self.AnchorView!.addSubview(newButton)

            if(i==0){
                
                let leadingConstraint = newButton.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant : 20)
                let trailingConstraint = newButton.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant:-20)
                let topContraint = newButton.topAnchor.constraint(equalTo: self.topAnchor, constant:20)
                // Set firstbutton to anchorframe.
                // All other buttons will be tied to the previous button-
                initialConstraints.append(contentsOf: [leadingConstraint,trailingConstraint,topContraint])
            }else{
                let topContraint = newButton.topAnchor.constraint(equalTo: self.ButtonViews[i-1].topAnchor, constant:50)
                let leadingConstraint = newButton.leadingAnchor.constraint(equalTo: self.ButtonViews[i-1].leadingAnchor)
                let trailingConstraint = newButton.trailingAnchor.constraint(equalTo: self.ButtonViews[i-1].trailingAnchor)
                 initialConstraints.append(contentsOf: [leadingConstraint,trailingConstraint,topContraint])
            }
        }
          NSLayoutConstraint.activate(initialConstraints)
    }
}
