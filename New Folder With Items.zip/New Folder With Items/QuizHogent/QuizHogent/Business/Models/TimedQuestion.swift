//
//  TimedQuestion.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 18/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//
// Class that resembles a normalquiz question where the reward is just based on the time nothing fancy
import Foundation

class TimedQuestion : QuizQuestion{
    
    override func GetReward() -> Int {
       return Timer
    }
    
}
