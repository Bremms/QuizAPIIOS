//
//  GameStartScreenViewController.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import UIKit

class QuizCategoryCell : UITableViewCell {
    
    @IBOutlet weak var CategoryTitle: UILabel!
    
    @IBOutlet weak var CategoryRanking: UILabel!

    
    @IBOutlet weak var Description: UILabel!
}

class GameStartScreenViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
  
    
    @IBOutlet weak var CategorieTableView: UITableView!
    
   
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return  Game.Instance.Categories.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! QuizCategoryCell
        
        cell.CategoryTitle?.text = Game.Instance.Categories[indexPath.row].Name
        
        cell.CategoryRanking.text = renderStarEmojis(ranking: Game.Instance.Categories[indexPath.row].CategoryAvgDificulty)
        
        cell.Description.text = Game.Instance.Categories[indexPath.row].Description
        
        return cell
    }
    
    func renderStarEmojis(ranking : Int) -> String{
        
        var result = ""
        
        for _ in 0..<ranking{
            result.append("⭐️")
        }
        
        return result
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        CategorieTableView.reloadData()
    }

    override func viewDidLoad() {
        CategorieTableView.estimatedRowHeight = 80
        CategorieTableView.rowHeight = 80
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        Game.Instance.fetchRandomCategories()
         super.viewWillAppear(animated)
        
    }
    //Cell selected
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedCategory = Game.Instance.Categories[indexPath.row]
        Game.Instance.CurrentSelectedCategory = selectedCategory
        let GameQuestionRepo = QuizQuestionRepository()
        do{
            try Game.Instance.SetQuestionEntries(quizQuestions: GameQuestionRepo.Fetch(ByID: selectedCategory.ID))
        }catch{
            print("Error happend fetch questions")
        }
     
        
        
      let controller =  self.storyboard?.instantiateViewController(withIdentifier: "QuestionScreen") as! QuestionController
        
        //https://stackoverflow.com/questions/24038215/how-to-navigate-from-one-view-controller-to-another-using-swift
        
        self.present(controller, animated: true,completion:nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
