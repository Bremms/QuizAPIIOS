//
//  QuestionController.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 19/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation
import UIKit


class QuestionController : UIViewController, GameActivityProtocol{
    
    
    var initialConstraints = [NSLayoutConstraint]()
    var buttonView : ButtonView?
    var newTextField : UITextField?
    var timer : Timer!
    @IBOutlet weak var MainStackView: UIStackView!
    
    @IBOutlet weak var SecondUiView: UIView!
    
    @IBOutlet weak var QuestionImage: UIImageView!
    
    @IBOutlet weak var QuestionDescription: UILabel!
    
    @IBOutlet weak var QuestionTimer: UILabel!
    
    @IBOutlet weak var Score: UILabel!
    
    var ButtonViews : [UIButton] = []
    
    
    
    func OnRepaintScreen() {
        
    }
    
    func DisableElement(object: Any) {
        let quizAnswer = object as! QuizAnswer
        if(quizAnswer != nil){
            for button in ButtonViews{
                if(button.tag == quizAnswer.ID)
                {
                    button.isEnabled = false
                    button.backgroundColor = UIColor.red
                }
            }
        }
    }
    
    func OnTimerEnded() {
       GoToNextAnswer()
    }
    
    func paintTimer(seconds : Int){
        QuestionTimer.text = "\(seconds) s"
    }
    
    @objc func TimerElapsed(){
        Game.Instance.GetCurrentQuestion()?.TimerElapsed()
        let timer = Game.Instance.GetCurrentQuestion()?.Timer
        paintTimer(seconds: timer!)
    }
    
    @objc func AnswerClicked(_ sender : UIButton){
       Game.Instance.OnQuestionAnswered(answerID: sender.tag)
       GoToNextAnswer()
       
    }
  
    @objc func AnswerEntered(_ sender : UIButton){
        var value = newTextField?.text
        var question = Game.Instance.OnQuestionAnswered(answer : value!)
        GoToNextAnswer()
    }
    
    func GoToNextAnswer(){
        //Clears the timer
        //If next question nil -> go to HIGHSCORE SCREEN else continue
        
         timer.invalidate()
        let question =  Game.Instance.GetNextQuestion()
        if(question == nil){
            
            //Store score
             DAL.Instance.StoreScore(score: Game.Instance.CurrentScore, categoryID: Game.Instance.CurrentSelectedCategory!.ID)
            
            let highscoreController = self.storyboard?.instantiateViewController(withIdentifier: "HighScoreScreen") as! HighScoreController
            
            self.present(highscoreController, animated: true,completion:nil)
            
        }else{
            let controller =  self.storyboard?.instantiateViewController(withIdentifier: "QuestionScreen") as! QuestionController
            self.present(controller, animated: true,completion:nil)
        }
    }
    
    override func viewDidLoad() {
       
        super.viewDidLoad()

        let question = Game.Instance.GetCurrentQuestion()
        question?.SetGameActivityHandler(gameActivityHandler: self)
        Score.text = "\(Game.Instance.CurrentScore)"
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(TimerElapsed), userInfo: nil, repeats: true)
        
        if(question?.PhotoExternalURL != nil){
            if let url = URL(string: question!.PhotoExternalURL!) {
                QuestionImage.contentMode = .scaleAspectFit
                downloadImage(url: url)
            }
        }
        
        QuestionDescription.text = question?.Question
        
        //Make view for openquestions or ButtonQuestions
        if(question is OpenQuestion){
             AddAnswersInTextField()
        }else{
             AddAnswersToViewInButtons()
        }
       
        
        
        paintTimer(seconds: question!.Timer)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func AddAnswersInTextField(){
        newTextField = UITextField()
        newTextField!.backgroundColor = UIColor.darkGray
        newTextField!.layer.borderColor = UIColor.black.cgColor
        newTextField!.translatesAutoresizingMaskIntoConstraints = false
        newTextField!.textColor = UIColor.white
        newTextField!.placeholder = "answer"
        
        let submitButton = UIButton()
        submitButton.backgroundColor = UIColor.darkGray
        submitButton.translatesAutoresizingMaskIntoConstraints = false
        submitButton.setTitle("Antwoord", for: UIControlState.normal)
       
        SecondUiView.addSubview(newTextField!)
        SecondUiView.addSubview(submitButton)
        
      
        newTextField!.frame.size.height = 75
    
       // let topContraint = newTextField!.topAnchor.constraint(equalTo: SecondUiView.topAnchor, constant:160)

        
        let leadingConstraint = newTextField?.leadingAnchor.constraint(equalTo: SecondUiView.leadingAnchor, constant : 20)
        let trailingConstraint = newTextField?.trailingAnchor.constraint(equalTo: SecondUiView.trailingAnchor, constant:-20)
        let topContraint = newTextField?.topAnchor.constraint(equalTo: SecondUiView.topAnchor, constant:20)
      
        let topContraint2 = submitButton.topAnchor.constraint(equalTo: newTextField!.topAnchor, constant:50)
        let leadingConstraint2 = submitButton.leadingAnchor.constraint(equalTo: newTextField!.leadingAnchor)
        let trailingConstraint2 = submitButton.trailingAnchor.constraint(equalTo: newTextField!.trailingAnchor)
        
        
        initialConstraints.append(contentsOf: [leadingConstraint!,trailingConstraint!,topContraint!,topContraint2,leadingConstraint2,trailingConstraint2])
      
        
        submitButton.addTarget(self, action:#selector(AnswerEntered(_:)), for: .touchUpInside)
        
        NSLayoutConstraint.activate(initialConstraints)
    }
    
    public func AddAnswersToViewInButtons(){
        ButtonViews = [UIButton]()
       
        for var i in 0..<Game.Instance.GetCurrentQuestion()!.PotentialAnswers.count{
            var answer = Game.Instance.GetCurrentQuestion()!.PotentialAnswers[i]
            
            let newButton = UIButton()
            newButton.translatesAutoresizingMaskIntoConstraints = false
            
            newButton.setTitle(answer.Description, for: UIControlState.normal)
            newButton.backgroundColor = UIColor.darkGray
             newButton.tag = answer.ID
            newButton.addTarget(self, action:#selector(AnswerClicked(_:)), for: .touchUpInside)
           
            ButtonViews.append(newButton)
            SecondUiView.addSubview(newButton)
            
            if(i==0){
                
                let leadingConstraint = newButton.leadingAnchor.constraint(equalTo: SecondUiView.leadingAnchor, constant : 20)
                let trailingConstraint = newButton.trailingAnchor.constraint(equalTo: SecondUiView.trailingAnchor, constant:-20)
                let topContraint = newButton.topAnchor.constraint(equalTo: SecondUiView.topAnchor, constant:20)
                // Set firstbutton to anchorframe.
                // All other buttons will be tied to the previous button-
                initialConstraints.append(contentsOf: [leadingConstraint,trailingConstraint,topContraint])
            }else{
                let topContraint = newButton.topAnchor.constraint(equalTo: self.ButtonViews[i-1].topAnchor, constant:50)
                let leadingConstraint = newButton.leadingAnchor.constraint(equalTo: self.ButtonViews[i-1].leadingAnchor)
                let trailingConstraint = newButton.trailingAnchor.constraint(equalTo: self.ButtonViews[i-1].trailingAnchor)
                initialConstraints.append(contentsOf: [leadingConstraint,trailingConstraint,topContraint])
            }
        }
        NSLayoutConstraint.activate(initialConstraints)
    }
    //https://stackoverflow.com/questions/24231680/loading-downloading-image-from-url-on-swift
    //Gans overnomen dit om images te downloaden over het web.
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    func downloadImage(url: URL) {
        print("Download Started")
        getDataFromUrl(url: url) { data, response, error in
            guard let data = data, error == nil else { return }
            print(response?.suggestedFilename ?? url.lastPathComponent)
            print("Download Finished")
            DispatchQueue.main.async() {
                self.QuestionImage.image = UIImage(data: data)
            }
        }
    }
}
