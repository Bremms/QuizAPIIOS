//
//  ViewController.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 16/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved. NiceQuiz C
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var GamerTagInputField: UITextField!
    
    //Save gamertag in globalvalue so we can store it in the highscores later...
    @IBAction func SaveGamerTag(_ sender: Any) {
        var loggedInPerson = GamerTagInputField.text!
        
        if(loggedInPerson.isEmpty){
            loggedInPerson  = Default.DEFAULT_GAMER_TAG.rawValue
        }
        
        UserDefaults.standard.set(loggedInPerson, forKey: Default.USERKEY.rawValue)
        
        
      
        
        
        NavigateToGameStartScreen()
    }
    
    func setCategories(categories : [QuizCategory]?) -> Void {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func NavigateToGameStartScreen() {
        let startScreenController = self.storyboard?.instantiateViewController(withIdentifier: "GameStartScreen") as! GameStartScreenViewController
        
//https://stackoverflow.com/questions/24038215/how-to-navigate-from-one-view-controller-to-another-using-swift
        
        self.present(startScreenController, animated: true,completion:nil)
        
        
    }

}

