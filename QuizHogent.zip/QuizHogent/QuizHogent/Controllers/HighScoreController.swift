//
//  HighScoreController.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 24/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import UIKit
import Foundation

class HighScoreCell : UITableViewCell {
    
    
    @IBOutlet weak var GamerTagLabel: UILabel!
    
    @IBOutlet weak var Score: UILabel!
  
}

class HighScoreController  : UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var Highscores : [HighScore] = []
    
    @IBAction func GoToCategories(_ sender: UIButton) {
        
        let startScreenController = self.storyboard?.instantiateViewController(withIdentifier: "GameStartScreen") as! GameStartScreenViewController
        
        self.present(startScreenController, animated: true,completion:nil)
    }
    @IBOutlet weak var HighScoreTable: UITableView!
    
    @IBOutlet weak var HighScoreTotalLabel: UILabel!
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
      return Highscores.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "HighscoreCell", for: indexPath) as! HighScoreCell
        
        if(Highscores.count>0){
            cell.GamerTagLabel?.text = Highscores[indexPath.row].PersonTag
            
            cell.Score.text = "\(Highscores[indexPath.row].Score)"
        }

        return cell
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        HighScoreTable.reloadData()
    }
    
    override func viewDidLoad() {
        HighScoreTable.estimatedRowHeight = 80
        HighScoreTable.rowHeight = 80
        
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        HighScoreTotalLabel.text?.append("\(Game.Instance.CurrentScore)")
        Game.Instance.CurrentScore = 0//Reset score
        do{
            try Highscores = DAL.Instance.FetchHighscores(categoryID: Game.Instance.CurrentSelectedCategory!.ID)
           
            
        }catch{
            
        }
       
        super.viewWillAppear(animated)
    }
    
    
}
