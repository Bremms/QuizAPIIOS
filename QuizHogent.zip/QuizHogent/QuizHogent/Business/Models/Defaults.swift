//
//  Defaults.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

enum Default : String {
    
    case DEFAULT_GAMER_TAG = "Doe"
    case GAME_ON_DEBUG = "1"
    case AMT_FETCHED_CATEGORIES = "5"
    case USERKEY = "currentUser"
    
}
