//
//  QuizQuestionDummyRepository.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 18/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation
import GameplayKit
class QuizQuestionRepository : RepositoryProtocol{
    
    func Save(obj: Any) throws {
        throw GameErrors.NotImplemented
    }
    

    var quizQuestion : [QuizQuestion]
    
    
    init(){
        quizQuestion = [QuizQuestion]()
        
        let question1 = OpenQuestion(categoryID : 5,id : 1, question : "Wie won in het seizoen 2005-2006 de Premier League",photoInternalPath : nil,photoExternalUrl : "https://cdn.bleacherreport.net/images/team_logos/328x328/epl.png")
        question1.addAnswer(answer: QuizAnswer(id: 1, quizQuestionID: 1, description: "Chelsea", isAnwser: true))
        question1.addAnswer(answer: QuizAnswer(id: 2, quizQuestionID: 2, description: "Manchester Utd", isAnwser: false))
        question1.addAnswer(answer: QuizAnswer(id: 3, quizQuestionID: 3, description: "Liverpool", isAnwser: false))
        question1.addAnswer(answer: QuizAnswer(id: 4, quizQuestionID: 4, description: "Arsenal", isAnwser: false))
        
        let question2 = DisableAnswerQuestion(categoryID : 5,id : 2, question : "Wie was speler van het seizoen in 2014/2015",photoInternalPath : nil,photoExternalUrl : nil)
        question2.addAnswer(answer: QuizAnswer(id: 5, quizQuestionID: 2, description: "Jamy Vardy", isAnwser: true))
        question2.addAnswer(answer: QuizAnswer(id: 6, quizQuestionID: 2, description: "Hary Kane", isAnwser: false))
        question2.addAnswer(answer: QuizAnswer(id: 7, quizQuestionID: 2, description: "Mesut Ozil", isAnwser: false))
        question2.addAnswer(answer: QuizAnswer(id: 8, quizQuestionID: 2, description: "Kevin De Bruine", isAnwser: false))
        
        let question3 = DisableAnswerQuestion(categoryID : 5,id : 3, question : "Welke club won de Champions League het meest",photoInternalPath : nil,photoExternalUrl : nil)
        question3.addAnswer(answer: QuizAnswer(id: 10, quizQuestionID: 3, description: "AC Milan", isAnwser: false))
        question3.addAnswer(answer: QuizAnswer(id:11, quizQuestionID: 3, description: "Barcelona", isAnwser: false))
        question3.addAnswer(answer: QuizAnswer(id: 12, quizQuestionID: 3, description: "Bayern", isAnwser: false))
                question3.addAnswer(answer: QuizAnswer(id: 13, quizQuestionID: 3, description: "Real Madrid", isAnwser: true))
        
        
        let question4 = QuizQuestion(categoryID : 5,id : 4, question : "Wie won de ballon d'or het meest",photoInternalPath : nil,photoExternalUrl : nil)
        question4.addAnswer(answer: QuizAnswer(id: 14, quizQuestionID: 4, description: "Lionel Messi", isAnwser: false))
        question4.addAnswer(answer: QuizAnswer(id:15, quizQuestionID: 4, description: "Cristiano Ronaldo", isAnwser: true))
        
         quizQuestion.append(question1)
         quizQuestion.append(question2)
         quizQuestion.append(question3)
         quizQuestion.append(question4)
        
    }
    
    func Fetch<QuizQuestion>() throws -> [QuizQuestion] {
         return quizQuestion as! [QuizQuestion]
    }
    
    func FetchRandom<QuizQuestion>(amount: Int) throws -> [QuizQuestion] {
        let shuffledArraySlices = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: quizQuestion).prefix(amount)
        
        let shuffledArray : [QuizQuestion] = Array(shuffledArraySlices) as! [QuizQuestion]
        
        return shuffledArray
    }
    
    func FirstOrDefault<QuizQuestion>(id: Int) throws -> QuizQuestion! {
        if let i = quizQuestion.index(where : {$0.ID == id}){
            return quizQuestion[i] as! QuizQuestion
        }
        return nil
    }
    
    func Fetch<QuizQuestion>(ByID: Int) throws -> [QuizQuestion] {
        var newArray = [QuizQuestion]()
        
        for question in quizQuestion{
            if(question.CategoryID == ByID){
               let question_ = question as! QuizQuestion
                newArray.append(question_)
            }
        }
//
//        if let i = quizQuestion.index(where : {$0.CategoryID == ByID}){
//            let question = quizQuestion[i] as! QuizQuestion
//            newArray.append(question)
//        }
       return newArray
    }
    
}
