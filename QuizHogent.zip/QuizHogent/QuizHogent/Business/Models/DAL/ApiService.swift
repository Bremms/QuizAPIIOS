//
//  ApiService.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 06/01/2018.
//  Copyright © 2018 Arne De Bremme. All rights reserved.cs
//

import Foundation

class ApiService{
    var BASE_URL : String = "http://specflow.test.starringjane.be/api/"
    var fetchCategories_URL : String = "Category/FetchRandomCategories"
    var fetchHighscoresFor_URL : String =  "HighScore/FetchHighscoreFor"
    var fetchQuizQuestionFor_URL : String = "Quiz/fetchQuizQuestion"
    
        public func fetchQuizCategories(completion: @escaping ([QuizCategory]?) -> Void) {
            let urlSession = URLSession(configuration: .default)
            
            let url = URL(string: BASE_URL + fetchCategories_URL)!
            
            var urlRequest = URLRequest(
                url: url,
                cachePolicy: .reloadIgnoringLocalAndRemoteCacheData,
                timeoutInterval: 10.0 * 1000)
            urlRequest.httpMethod = "GET"
            let task = urlSession.dataTask(with: urlRequest)
            { (data, response, error) -> Void in
                
                print( data?.base64EncodedString())
                guard error == nil else {
                    print("Error fetching categories \(error)")
                    completion(nil)
                    return
                }
                
                guard let responseData = data else {
                    print("Error: did not receive data")
                  
                    completion(nil)
                    return
                }
                let decoder = JSONDecoder()
                do {
                    let categories = try decoder.decode([QuizCategory].self, from: responseData)
                    completion(categories)
                } catch {
                    print("error trying convert to JSON")
                    print(error)
                    completion(nil)
                }
            }
            
            
            task.resume()
        }
    
    public func fetchHighscoresFor(catID : Int, completion: @escaping ([HighScore]?) -> Void) {
        let urlSession = URLSession(configuration: .default)
        
        let url = URL(string: BASE_URL + fetchHighscoresFor_URL+"?CatID=\(catID)")!
        
        var urlRequest = URLRequest(
            url: url,
            cachePolicy: .reloadIgnoringLocalAndRemoteCacheData,
            timeoutInterval: 10.0 * 1000)
        urlRequest.httpMethod = "GET"
        let task = urlSession.dataTask(with: urlRequest)
        { (data, response, error) -> Void in
            
            print( data?.base64EncodedString())
            guard error == nil else {
                print("Error fetching categories \(error)")
                completion(nil)
                return
            }
            
            guard let responseData = data else {
                print("Error: did not receive data")
                
                completion(nil)
                return
            }
            let decoder = JSONDecoder()
            do {
                let scores = try decoder.decode([HighScore].self, from: responseData)
                completion(scores)
            } catch {
                print("error trying convert to JSON")
                print(error)
                completion(nil)
            }
        }
        
        
        task.resume()
    }
    
    public func fetchQuizQuestions(catID : Int, completion: @escaping ([QuizQuestion]?) -> Void) {
        let urlSession = URLSession(configuration: .default)
        
        let url = URL(string: BASE_URL + fetchQuizQuestionFor_URL+"?CatID=\(catID)")!
        
        var urlRequest = URLRequest(
            url: url,
            cachePolicy: .reloadIgnoringLocalAndRemoteCacheData,
            timeoutInterval: 10.0 * 1000)
        urlRequest.httpMethod = "GET"
        let task = urlSession.dataTask(with: urlRequest)
        { (data, response, error) -> Void in
            
            print( data?.base64EncodedString())
            guard error == nil else {
                print("Error fetching categories \(error)")
                completion(nil)
                return
            }
            
            guard let responseData = data else {
                print("Error: did not receive data")
                
                completion(nil)
                return
            }
            let decoder = JSONDecoder()
            do {
                let scores = try decoder.decode([QuizQuestion].self, from: responseData)
                completion(scores)
            } catch {
                print("error trying convert to JSON")
                print(error)
                completion(nil)
            }
        }
        
        
        task.resume()
    }
}
