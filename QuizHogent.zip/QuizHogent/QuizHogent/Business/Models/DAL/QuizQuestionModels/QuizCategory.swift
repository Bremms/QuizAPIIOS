//
//  QuizCategory.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class QuizCategory : Codable {
    var Name : String
    var CategoryAvgDificulty : Int
    var ID : Int
    var Description : String
    init(name : String,avgDificulty : Int,id : Int,description : String){
        Name = name
        ID = id
        CategoryAvgDificulty = avgDificulty
        Description = description
    }
    init?(json: [String: Any]) {
        guard let Name = json["Name"] as? String,
            let CategoryAvgDificulty = json["CategoryAvgDificulty"] as? Int,
            let ID = json["ID"] as? Int,
            let Description = json["Description"] as? String else {
                return nil
        }
        self.Name = Name
        self.CategoryAvgDificulty = CategoryAvgDificulty
        self.ID = ID
        self.Description = Description
    }
    
}
