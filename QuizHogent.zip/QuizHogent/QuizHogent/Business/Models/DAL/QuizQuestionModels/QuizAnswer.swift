//
//  QuizAnswer.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 18/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation
class QuizAnswer : Decodable {
    var ID : Int
    var QuizQuestionID : Int
    var Description : String
    var IsAnswer = Bool()
     var IsDisabled : Bool
    init(id : Int, quizQuestionID : Int, description : String, isAnwser : Bool){
        ID = id
        IsAnswer = isAnwser
       QuizQuestionID =  quizQuestionID
        Description = description
        IsDisabled  = false
    }
    enum MyStructKeys: String, CodingKey { // declaring our keys
        case quizQuestionID = "QuizQuestionID"
        case id = "ID"
        case answer = "Answer"
        case isAnswer = "IsRightAnswer"
     
      
    }
    
//    init?(json: [String: Any]) {
//        guard let ID = json["ID"] as? Int,
//            let QuizQuestionID = json["QuizQuestionID"] as? Int,
//            let Description = json["Description"] as? String,
//            let IsAnswer = json[ "IsAnswer"] as? Bool,
//            let IsDisabled = json["IsDisabled"] as? Bool
//        else {
//                return nil
//        }
//        self.ID = ID
//        self.QuizQuestionID = QuizQuestionID
//        self.IsDisabled = IsDisabled
//        self.IsAnswer = IsAnswer
//        self.Description = Description
//    }
//}
convenience required init(from decoder: Decoder) throws {
    
    let container = try decoder.container(keyedBy: MyStructKeys.self) //
    let questionID: Int = try container.decode(Int.self, forKey: .quizQuestionID )
    let id : Int = try container.decode(Int.self, forKey: .id)
    let description : String = try container.decode(String.self, forKey: .answer)
    let isAnswer : Bool = try container.decode(Bool.self, forKey: .isAnswer)
    
    
    self.init(id : id, quizQuestionID : questionID, description : description, isAnwser : isAnswer) // initializing our struct
 
}
    
    
}
