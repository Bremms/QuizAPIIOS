//
//  DisableAnswerQuestion.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 23/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class DisableAnswerQuestion : QuizQuestion

{
    override func TimerElapsed(){
        super.TimerElapsed()
        
        if(Timer == InitTimer - 5){
            GameActivityHandler != nil ? GameActivityHandler?.DisableElement(object: GetAnswerToDisable() as Any) : () // Tell the controller to Disable the first answer in 5 seconds
        }
        
        if(Timer == InitTimer - 10){
              GameActivityHandler != nil ? GameActivityHandler?.DisableElement(object: GetAnswerToDisable() as Any) : () // Tell the controller to Disable the first answer in 5 seconds
        }
    }
    
    override func GetReward() -> Int {
      return Timer + (GetAmountNonDisabled() * 2)
    }
    
    private func GetAnswerToDisable() -> QuizAnswer?{
        //https://stackoverflow.com/questions/24003191/pick-a-random-element-from-an-array
        //To get random integer
        
        //Search the wrong answers and pick one randomly
        
        var indexWithWrongAnswers = [Int]()
        for var i in 0..<PotentialAnswers.count {
            let answer = PotentialAnswers[i]
            
            if(!answer.IsAnswer && !answer.IsDisabled){
                indexWithWrongAnswers.append(i)
            }
        }
        if(indexWithWrongAnswers.count>0){
            let randomIndex = Int(arc4random_uniform(UInt32(indexWithWrongAnswers.count)))
            let answerOnIndex = PotentialAnswers[indexWithWrongAnswers[randomIndex]]
            return answerOnIndex
        }else{
            return nil
        }
    }
    
  
}
