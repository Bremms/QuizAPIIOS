//
//  OpenQuizQuestion.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 24/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class OpenQuestion : QuizQuestion{
    
    override func GetReward() -> Int {
        return Timer + 15
    }
    
    func AnswerOpenQuestion(answer : String) -> Bool{
        for var posibleAnswer in PotentialAnswers{
            if(posibleAnswer.IsAnswer){
                if posibleAnswer.Description.lowercased() == answer.lowercased() {
                    return true
                }
            }
        }
        return false
    }
    
}
