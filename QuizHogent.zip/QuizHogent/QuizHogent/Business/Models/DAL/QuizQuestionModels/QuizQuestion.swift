//
//  QuizQuestion.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class QuizQuestion : Decodable{
    
    var Question : String
    var PhotoInternalPath : String? //Path to internal file
    var PhotoExternalURL : String? //URL to a website
    var CategoryID : Int
    var ID : Int
    let InitTimer = 30
    var Timer : Int
   
    var PotentialAnswers : [QuizAnswer]
    var GameActivityHandler : GameActivityProtocol? //Protocol to notify controller about critical changes
    
    enum MyStructKeys: String, CodingKey { // declaring our keys
        case question = "Question"
        case id = "ID"
        case photoInternalPath = "PhotoInternalPath"
        case photoExternalPath = "PhotoExternalURL"
        case categoryID = "CategoryID"
        case quizAnswer = "QuizAnswers"
    }
   
    
    init(categoryID catID : Int, id : Int, question : String, photoInternalPath : String?, photoExternalUrl : String?){
        ID = id
        CategoryID = catID
        Question = question
        PhotoInternalPath = photoInternalPath
        PhotoExternalURL = photoExternalUrl
        PotentialAnswers = [QuizAnswer]()
        Timer = InitTimer //default 30seconds to answer a question
    
 
    }
    convenience required init(from decoder: Decoder) throws {
   
        let container = try decoder.container(keyedBy: MyStructKeys.self) //
        let question: String = try container.decode(String.self, forKey: .question)
        let id: Int = try container.decode(Int.self, forKey: .id)
        let photoInternal: String? = try container.decode(String?.self, forKey: .photoInternalPath)
        let photoExternal : String? = try container.decode(String?.self, forKey: .photoExternalPath)
        let categoryID : Int = try container.decode(Int.self, forKey: .categoryID)
        let potentialAnswers = try container.decode([QuizAnswer].self, forKey: .quizAnswer)
        
        self.init(categoryID : categoryID, id : id, question : question, photoInternalPath : photoInternal, photoExternalUrl : photoExternal) // initializing our struct
        PotentialAnswers = potentialAnswers
    }


    func SetGameActivityHandler(gameActivityHandler handler : GameActivityProtocol){
        GameActivityHandler = handler
    }

    func addAnswer(answer : QuizAnswer){
        PotentialAnswers.append(answer)
        GameActivityHandler != nil ? GameActivityHandler!.OnRepaintScreen() : ()
    }

    func TimerElapsed(){
        Timer = Timer - 1

        if Timer == 0 {
            GameActivityHandler != nil ? GameActivityHandler!.OnTimerEnded() : ()
        }

    }

    func AnswerQuestion(id : Int) -> Bool{
        let foundAnswer = SearchAnswerByID(id: id)
        if foundAnswer != nil{
            return foundAnswer!.IsAnswer
        }
        return false
    }

    func GetReward() -> Int {
       return Timer //Default implementation of get raward
    }

    private func SearchAnswerByID(id : Int) -> QuizAnswer?{
        if let i = PotentialAnswers.index(where : {$0.ID == id}){
            return PotentialAnswers[i]
        }
        return nil
    }

    public func GetAmountNonDisabled() -> Int{
        var amt = 0

        for answer in PotentialAnswers{
            if(answer.IsDisabled){
                amt += 1
            }
        }

        return amt

    }
    
}
