//
//  IRepository.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

protocol RepositoryProtocol {
    
    func Fetch<T>() throws -> [T]
    
    func Fetch<T>(ByID : Int) throws -> [T]
    
    func FetchRandom<T> (amount : Int) throws -> [T]
    
    func FirstOrDefault<T>(id : Int) throws -> T!
    
    func Save(obj : Any) throws 
    
}
