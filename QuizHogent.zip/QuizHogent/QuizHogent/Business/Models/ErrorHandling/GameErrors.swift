//
//  GameErrors.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation
enum GameErrors: Error {
    case NotImplemented
}
