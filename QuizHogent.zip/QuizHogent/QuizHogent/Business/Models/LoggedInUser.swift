//
//  LoggedInUser.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 17/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

public class LoggedInUser{
    var gamerTag : String
    
    init(Gamertag tag : String) {
        gamerTag = tag
    }
    
}
