//
//  HighScore.swift
//  QuizHogent
//
//  Created by Arne De Bremme on 24/12/2017.
//  Copyright © 2017 Arne De Bremme. All rights reserved.
//

import Foundation

class HighScore : Codable {
    
    var PersonTag : String
    var CatID : Int
    var Score : Int
    var ID : Int
    init(id : Int, personTag : String,score : Int,catID : Int){
        
        PersonTag = personTag
        ID = id
        Score = score
        CatID = catID
    
    }
    
    init?(json: [String: Any]) {
        guard let PersonTag = json["PersonTag"] as? String,
            let CatID = json["CatID"] as? Int,
            let ID = json["ID"] as? Int,
            let Score = json["Score"] as? Int else {
                return nil
        }
        self.PersonTag = PersonTag
        self.CatID = CatID
        self.ID = ID
      
        self.Score = Score
        
    }
}
